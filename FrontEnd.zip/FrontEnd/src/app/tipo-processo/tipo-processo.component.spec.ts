import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TipoProcessoComponent } from './tipo-processo.component';

describe('TipoProcessoComponent', () => {
  let component: TipoProcessoComponent;
  let fixture: ComponentFixture<TipoProcessoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TipoProcessoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TipoProcessoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
