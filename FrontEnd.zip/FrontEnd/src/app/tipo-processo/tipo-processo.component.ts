import { Component } from '@angular/core';

@Component({
  selector: 'app-tipo-processo',
  templateUrl: './tipo-processo.component.html',
  styleUrl: './tipo-processo.component.css'
})
export class TipoProcessoComponent {

}
