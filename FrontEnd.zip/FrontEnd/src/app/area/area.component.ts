import { HttpClient } from '@angular/common/http';
import { Component, Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})


@Component({
  selector: 'app-area',
  templateUrl: './area.component.html',
  styleUrl: './area.component.css'
})
export class AreaComponent {

  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getAreas();
  }

  getAreas() {
    return this.http.get('https://localhost:7250/api/Area');
  }

  title = 'FrontEnd';
}
