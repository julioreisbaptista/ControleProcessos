import { Component, OnInit } from '@angular/core';
import { AreaService } from './area.service';

@Component({
  selector: 'app-area-grid',
  templateUrl: './area-grid.component.html',
  styleUrls: ['./area-grid.component.css']
})
export class AreaGridComponent implements OnInit {
  areas: any[];

  constructor(private areaService: AreaService) { }

  ngOnInit(): void {
    this.areaService.getAreas().subscribe((data: any[]) => {
      this.areas = data;
    });
  }
}
