import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AreaComponent } from './area/area.component';
import { TipoProcessoComponent } from './tipo-processo/tipo-processo.component';
import { ProcessoComponent } from './processo/processo.component';

@NgModule({
  declarations: [
    AppComponent,
    AreaComponent,
    TipoProcessoComponent,
    ProcessoComponent
  ],
  imports: [
    BrowserModule, HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
